const mongoose = require('mongoose');

var Student = mongoose.model('Student', {
    name: { type: String },
    address: { type: String },
    marks: { type: String },
    board: { type: String },
    stream: { type: String }
});

module.exports = { Student };


