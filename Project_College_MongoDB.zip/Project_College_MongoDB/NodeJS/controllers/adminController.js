const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;
var {Admin}= require('../models/admin');


router.get('/', (req, res) => {
 /*  admin = {
       username : 'Saikat',
       password:'123'
   };

   res.send(admin);
   */
   Admin.find((err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving Admin :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.get('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

        Admin.findById(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Retriving Admin :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.post('/', (req, res) => {
    var admin = new Admin({
        username: req.body.username,
        password: req.body.password
        
    });
    admin.save((err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Student Save :' + JSON.stringify(err, undefined, 2)); }
    });
});

module.exports = router;