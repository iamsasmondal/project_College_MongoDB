import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response, Headers } from '@angular/http';

import {AdminService} from '../shared/admin.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  private checkvalid:boolean=false;

  todaydate :any ;
  adminDetails:any=[];
  constructor(private router: Router,private http:Http, private adminservice:AdminService) { 

  }


  readonly baseURL = 'http://localhost:3000/admin';

  getAdmin(){
    this.http.get(this.baseURL).subscribe((res:Response)=>{
        this.adminDetails=res.json();
      }
    )
  }

  

  redir(value: any){
    // The parameter "value" contains the entire form data, i.e. the values in the username and text fields
    // The field values can then be accessed using their names "uid" and "pwd"

    // Checking for blank fields submission
    // If not blank or null (in case the fields are "reset"), the userid is stored in the local computer's browser cache
    // The current user is then logged in and redirected to the welcome page
    this.checkvalid=true;
    if((value.uid==this.adminDetails[0].username) && (value.pwd !=this.adminDetails[0].password && value.pwd!='')){

      alert('Incorrect Input');
    
    }
    else if((value.uid!=this.adminDetails[0].username && value.uid!='' ) && (value.pwd ==this.adminDetails[0].password)){
     
      alert('Incorrect Input');
      
    }
    else if((value.uid!=this.adminDetails[0].username) && (value.pwd !=this.adminDetails[0].password)){
     
      alert('Incorrect Input');
      
    }
   
    else if((value.uid== this.adminDetails[0].username ) && (value.pwd ==this.adminDetails[0].password)){
      localStorage.setItem("loginSuccess","1") ;
     
      this.router.navigate(['admin-home']);
    }
    
    // If any one of the fields are empty on "submission", alert is shown  
  }

  ngOnInit() {
   // this.fetchData();
   this.getAdmin();
    
  }

}
