import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { FormGroup, FormControl, NgForm } from '@angular/forms';
import { from } from 'rxjs';

import {StudentService} from '../shared/student.service';
import { Student } from '../shared/student.model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  constructor(private http: Http, private studentService:StudentService) {}
  confirmationString:string = "You have registered successfully";
  // isRegistered: boolean = false;
  
  onSubmit(form :NgForm){
  this.studentService.postStudent(form.value).subscribe((res)=>{
   // this.isRegistered=true;
  //  var resetForm=<HTMLFormElement>document.getElementById("studentFormID"); 
   // resetForm.reset();
    this.resetForm();
    this.refreshStudent();
    alert(this.confirmationString);
  });
}

resetForm(form?: NgForm) {
  if (form)
    form.reset();
  this.studentService.selectedStudent = {
    _id: "",
    name: "",
    address: "",
    marks: "",
    board: "",
    stream:""
  }
}

refreshStudent() {
  this.studentService.getStudent().subscribe((res) => {
    this.studentService.students = res as Student[];
  });
}


ngOnInit(){
this.resetForm();
this.refreshStudent();
} 

}
