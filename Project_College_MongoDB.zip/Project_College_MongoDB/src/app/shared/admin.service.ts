import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Admin} from './admin.model' 

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  admins:Admin[];
  readonly baseURL = 'http://localhost:3000/admin';

  constructor(private http: HttpClient) { }

 getAdmin(){
   return this.http.get(this.baseURL);
 }
}
