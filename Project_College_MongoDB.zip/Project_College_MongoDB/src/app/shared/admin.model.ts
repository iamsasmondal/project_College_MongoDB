export class Admin{
    _id: String;
    username: String ;
    password :String
}