export class Student {
    _id: String;
    name: String ;
    address: String ;
    marks:String ;
    board: String ;
    stream: String ;
}